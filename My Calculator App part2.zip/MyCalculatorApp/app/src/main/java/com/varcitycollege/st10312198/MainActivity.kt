package com.varcitycollege.st10312198

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlin.math.absoluteValue
import kotlin.math.pow

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        var num1 = findViewById<EditText>(R.id.number1)
        var num2 = findViewById<EditText>(R.id.number2)
        var button = findViewById<Button>(R.id.button)
        var button2 = findViewById<Button>(R.id.button2)
        var button3 = findViewById<Button>(R.id.button3)
        var button4 = findViewById<Button>(R.id.button4)
        var button5 = findViewById<Button>(R.id.button5)
        var button6 = findViewById<Button>(R.id.button6)
        var clearbutton = findViewById<Button>(R.id.clearbutton)
        var edtanswer = findViewById<TextView>(R.id.edtanswer)


        button.setOnClickListener {
            var DifferenceStorage =
                num1.text.toString().toInt() +
                        num2.text.toString().toInt()
            edtanswer.text =
                DifferenceStorage.toString()
        }
        button2.setOnClickListener {
            var DifferenceStorage =
                num1.text.toString().toInt() -
                        num2.text.toString().toInt()
            edtanswer.text =
                DifferenceStorage.toString()
        }
        button3.setOnClickListener {
            var DifferenceStorage =

                num1.text.toString().toInt() *
                        num2.text.toString().toInt()
            edtanswer.text =
                DifferenceStorage.toString()
        }
        button4.setOnClickListener {
            if(num2.text.toString().toInt() != 0) {
                var DifferenceStorage =
                    num1.text.toString().toInt() /
                            num2.text.toString().toInt()
                edtanswer.text =
                    DifferenceStorage.toString()
            } else {
                edtanswer.text = "Cant divide by zero"
            }

        }
        button5.setOnClickListener {
            var DifferenceStorage = Math.sqrt(num1.text.toString().toInt().toDouble())

            edtanswer.text = DifferenceStorage.toString()
            val number = num1.text.toString().toDouble()

            if (number >= 0) {
                val result = Math.sqrt(number)
                edtanswer.text = "sqrt($number) = $result"
            } else {
                val result = Math.sqrt(number.absoluteValue)
                edtanswer.text = "sqrt($number) = ${result}i"
            }

        }
        button6.setOnClickListener {
            var base = num1.text.toString().toDouble()
            var exponent=num2.text.toString().toDouble()
            var result = base.pow(exponent)
            edtanswer.text = "$base raised to the power of $exponent is $result"
        }



        clearbutton.setOnClickListener {
            num1.setText("");
            num2.setText("");
            edtanswer.setText("");
            Toast.makeText(this,"Cleared", Toast.LENGTH_SHORT).show()
        }


    }
}

//--------code attribution-------//

//(Create a Simple Calculator App in Android Studio - Kotlin | For Beginners 2022)//
//Available at: (https://youtu.be/v24Bhk7wQI8?si=NRDy1gFoomzP5zWC)//
//Accessed on:(22 August 2023)//

//(Create a Calculator App in Minutes - Android Studio Tutorial)//
//Available at: (https://youtu.be/4DGLcL4v6Qo?si=zgWYxGCmx6zcQHO7)
//Accessed on:(21 August 2023)//

//(Simple Calculator Using Kotlin)//
//Available at: (https://youtu.be/Zi1XgFTUH9k?si=3h605K3VhU-VAr6o)//
//Accessed on:(22 August 2023)//

//(sqrt in kotlin)//
//Available at: (https://youtu.be/B8XKqJj0Sho?si=zQKSJvBytA2tMFnA)//
//Accessed on:(25 September 2023)//